import AbstractObservable from '../mock/utils';

export default class CommentsModel extends AbstractObservable {

}
